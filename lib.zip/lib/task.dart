class Task {
  final String name;
  final int timeInMinutes;

  Task(this.name, {required this.timeInMinutes});
}
